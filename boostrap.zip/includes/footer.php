</div>
<footer class="bg-light text-center p-4">
    <p>Criado com <a href="https://getbootstrap.com/">Bootstrap</a></p>
    <p>SENAC - São Miguel do Oeste</p>
</footer>
</body>
</html>